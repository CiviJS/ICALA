<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/usuarios/editarUsuario.css'); ?>
</head>
<body>
    <div class="layout-container fade-in">

    <div class="main-header" style="border-left: 5px solid var(--success);">
        <a href=<?php echo e(url('/')); ?> class="btn btn-outline">
            &larr; Volver
        </a>        
        <?php if(session('message')): ?>
            <div class="alert-box">
                <span>✅</span> <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
        
        <div class="brand">
             <h1>Editar Usuario: <?php echo e($usuario->nombre); ?></h1>
             <p class="subtitle">Modifique los campos necesarios y guarde los cambios.</p>
        </div>
       
    </div>
 
    <div class="card-wrapper">
        <form action="<?php echo e(url('/Usuario/update', $usuario->UUID)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?> <div class="form-group">
                <label for="nombre">Nombre:</label>
                <input type="text" id="nombre" name="nombre" value="<?php echo e(old('nombre', $usuario->nombre)); ?>" required>
                <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error-message"><?php echo e($errors->first('nombre')); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="fechaNacimiento">Fecha de Nacimiento:</label>
                <input type="date" id="fechaNacimiento" name="fechaNacimiento" value="<?php echo e(old('fechaNacimiento', $usuario->fechaNacimiento)); ?>" required>
                <?php $__errorArgs = ['fechaNacimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error-message"><?php echo e($errors->first('fechaNacimiento')); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="fechaIngreso">Fecha de Ingreso:</label>
                <input type="date" id="fechaIngreso" name="fechaIngreso" value="<?php echo e(old('fechaIngreso', $usuario->fechaIngreso)); ?>" required>
                <?php $__errorArgs = ['fechaIngreso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error-message"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="telefono">Teléfono:</label>
                <input type="text" id="telefono" name="telefono" value="<?php echo e(old('telefono', $usuario->telefono)); ?>" required>
                <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error-message"><?php echo e($errors->first('telefono')); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-actions">
                <a href="<?php echo e(url('/')); ?>" class="btn btn-outline">Cancelar</a>
                <button type="submit" class="btn btn-primary">Guardar Cambios</button>
            </div>
        </form>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Iglesia\GestionDeAsistenciaIglesia\resources\views\usuario\editarUsuario.blade.php ENDPATH**/ ?>