<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Integrantes - ICALA</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css','resources/js/app.js'); ?>
    
</head>
<body class="fade-in">
     <?php if(session('error')): ?>
                <div class="alert-box-error">
                    <span>Error: </span> <?php echo e(session('error')); ?>

                </div>
    <?php endif; ?>
    <div class="layout-container">
        <header class="main-header">
            <div class="brand">
                <h1>
                    <span>⛪</span> ICALA 
                    <span class="subtitle">| Gestión de Integrantes</span>
                </h1>
            </div>
            

            <nav class="top-nav">
                <a href="<?php echo e(url('/planillas')); ?>" class="btn btn-outline">📋 Planillas</a>
                <a href="<?php echo e(url('/Reportes')); ?>" class="btn btn-outline">📊 Reportes</a>
                <a href="<?php echo e(url('/Usuario/crear')); ?>" class="btn btn-primary">+ Nuevo Usuario</a>
            </nav>
        </header>

        <main>
            <?php if(session('message')): ?>
                <div class="alert-box">
                    <span>✅</span> <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>
        

            <div class="toolbar">
                <h3>Base de Datos de Miembros</h3>
                   <a href="<?php echo e(url('/')); ?>" class="btn btn-outline">mostrar Todo</a>
                <form action="<?php echo e(url('usuario/buscar')); ?>" method="GET" class="search-bar">
                    <input type="text" name="campo" placeholder="Buscar nombre..." required>
                    <button type="submit" class="btn" style="background: none; padding: 0 10px;">🔍</button>
                </form>
                        
            </div>  
       
                                            
            <div class="table-responsive-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Nacimiento</th>
                            <th>Teléfono</th>
                            <th class="text-center">Asistencias</th>
                            <th class="text-center">Faltas</th>
                            <th class="text-center">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td data-label="Nombre"><strong><?php echo e($usuario->nombre); ?></strong></td>
                                <td data-label="Nacimiento"><?php echo e($usuario->fechaNacimiento); ?></td>
                                <td data-label="Teléfono"><?php echo e($usuario->telefono); ?></td>
                                <td data-label="Asistencias" class="text-center">
                                    <span class="badge badge-success"><?php echo e($usuario->planillas_count); ?></span>
                                </td>
                                <td data-label="Faltas" class="text-center">
                                    <span class="badge badge-danger"><?php echo e($usuario->NoAsistidas); ?></span>
                                </td> 
                                <td data-label="Acciones">
                                    <div class="action-group">
                                        <a href="<?php echo e(url('/Usuario/editar/' . $usuario->UUID)); ?>" class="btn-icon-action edit" title="Editar">
                                            ✏️
                                        </a>
                                        
                                        <form action="<?php echo e(url('/Usuario/borrar/' . $usuario->UUID)); ?>" method="POST" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn-icon-action delete" title="Eliminar" onclick="return confirm('⚠️ ¿Estás seguro de eliminar a <?php echo e($usuario->nombre); ?>?');">
                                                🗑️
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            
            <?php if($usuarios->isEmpty()): ?>
                <div style="text-align: center; padding: 40px; color: #64748b;">
                    <p>No se encontraron resultados.</p>
                </div>
            <?php endif; ?>

        </main>
    </div>

</body>
</html><?php /**PATH C:\xampp\htdocs\Iglesia\GestionDeAsistenciaIglesia\resources\views/home.blade.php ENDPATH**/ ?>