<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Reporte de Personal</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/reportes/reportes.css'); ?>
</head>
<body>
    <div style="padding: 20px;">
        <div class="container fade-in">
            
            <a href="<?php echo e(url('/')); ?>" class="btn-volver">
                &larr; Ir al Panel
            </a>

            <h2>🎂 Cumpleaños Hoy</h2>
            <?php if($cumpleAniosHoy->isEmpty()): ?>
                <p>Nadie cumple años hoy. ¡Un día tranquilo!</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Fecha de Nacimiento</th>
                            <th>Edad</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cumpleAniosHoy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($u->nombre); ?></td>
                            <td><?php echo e($u->fechaNacimiento); ?></td>
                            <td><?php echo e($u->edad); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <h2>🎉 Cumpleaños Mañana</h2>
            <?php if($cumpleAniosManana->isEmpty()): ?>
                <p>Nadie cumple años mañana.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Fecha de Nacimiento</th>
                            <th>Edad (actual)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cumpleAniosManana; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($u->nombre); ?></td>
                            <td><?php echo e($u->fechaNacimiento); ?></td>
                            <td><?php echo e($u->edad); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <h2>📌 Nuevos Integrantes (Este Mes)</h2>
            <?php if($Nusuarios->isEmpty()): ?>
                <p>No hay nuevos integrantes este mes.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Fecha de Ingreso</th>
                            <th>Teléfono</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $Nusuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($u->nombre); ?></td>
                            <td><?php echo e($u->fechaIngreso); ?></td>
                            <td><?php echo e($u->telefono); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>

        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\Iglesia\GestionDeAsistenciaIglesia\resources\views\reportes\reportes.blade.php ENDPATH**/ ?>