<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalle de Planilla</title>
    <!-- Fuente Google Fonts (Inter) -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
    <!-- Carga los estilos definidos arriba -->
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/planilla/verPlanilla.css'); ?>
</head>
<body class ="fade-in">

<div class="layout-container">


    <!-- Título y Botón Volver -->
    <h2>📋 Planilla del <?php echo e($planilla->FechaCreacion); ?></h2>
    <h1>Tipo de Actividad: <?php echo e($planilla->TipoDeActividad); ?></h1>
    <h1>Usuario a cargo: <?php echo e($planilla->encargado->nombre); ?></h1>
    <a href="<?php echo e(url('/planillas')); ?>" class="btn-volver">
        ⬅️ Volver al Listado
    </a>
         <?php if(session('error')): ?>
                <div class="alert-box">
                    <span>🚫🙅‍♀️</span> <?php echo e(session('error')); ?>

                </div>
                <br>
            <?php endif; ?>

    <!-- Tabla de Usuarios -->
    <table>
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Edad</th>
                <th>Teléfono</th>
                <th>Asistencia</th>
                <th>Opciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <!-- data-label para responsividad móvil -->
                <td data-label="Nombre"><?php echo e($usuario->nombre); ?></td>
                <td data-label="Edad"><?php echo e($usuario->edad); ?></td>
                <td data-label="Teléfono"><?php echo e($usuario->telefono); ?></td>

                <!-- Columna de Asistencia (con estilos dinámicos) -->
                <td data-label="Asistencia">
                    <?php if($usuario->asistencia): ?>
                        <span class="attendance-status status-asistio">Asistió</span>
                    <?php else: ?>
                        <span class="attendance-status status-no-asistio">No asistió</span>
                    <?php endif; ?>
                </td>

                <!-- Columna de Opciones (con botón dinámico) -->
                <td data-label="Acción">
                    <!-- Formulario de acción POST (cambiado a PUT recomendado para actualizaciones) -->
                    <form action="<?php echo e(url('/planilla/Asistencia/'.$planilla->UUID.'/'.$usuario->UUID)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <!-- Usar PUT o PATCH es más semántico para una actualización -->
                        <?php echo method_field('PUT'); ?> 
                        
                        <!-- Lógica para alternar el botón según el estado de asistencia -->
                        <?php if($usuario->asistencia): ?>
                            <!-- Si asistió, el botón es rojo para DESMARCAR (estado=0) -->
                            <input type="hidden" name="estado" value="0">
                            <button type="submit" class="btn-danger">
                                Desmarcar Asistencia
                            </button>
                        <?php else: ?>
                            <!-- Si NO asistió, el botón es verde para MARCAR (estado=1) -->
                            <input type="hidden" name="estado" value="1">
                            <button type="submit" class="btn-success">
                                Marcar Asistencia
                            </button>
                        <?php endif; ?>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\Iglesia\GestionDeAsistenciaIglesia\resources\views\planilla\verPlanilla.blade.php ENDPATH**/ ?>